import React from 'react'
import Tabadd from './Addproduct/Tabadd'

function Addproduct() {
  return (
    <div>
        <>
        <h1 class=' xl:text-2xl font-semibold	md:text-xl '>เพิ่มสินค้า</h1>
        <Tabadd/>
        </>
    </div>
  )
}

export default Addproduct