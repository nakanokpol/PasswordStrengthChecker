const global_url_token = {
    url: "http://5e32-2403-6200-88a4-4c62-ad67-2c72-81c8-4445.ngrok.io",
    admin_token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IkFkbWluMTAxIiwicm9sZSI6ImFkbWluIiwiaWF0IjoxNjUxNTgxMzQ4LCJleHAiOjE2NTE2MTczNDh9.OvH85V6H9wnQp4nRPXk2R9RoqRlg8jOM3OILZb3gaJ8",
    customer_token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImhlbGxvbGVlIiwicm9sZSI6ImN1c3RvbWVyIiwiaWF0IjoxNjUxNTgxNDA4LCJleHAiOjE2NTE2MTc0MDh9.x87k9EafH-WnOkAdDHWHAnNVvmSCNmqduNrm2ZjNs98",
    seller_token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImhlbGxvIiwicm9sZSI6InNlbGxlciIsImlhdCI6MTY1MTU4MTM4MywiZXhwIjoxNjUxNjE3MzgzfQ.Ep4i2AJvsVRklO-sHvbcLzu1V4i1fFckzL0OqLW0zKU"
};

export {global_url_token};