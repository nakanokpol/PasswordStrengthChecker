import { createContext } from "react";

const OrderID_API = createContext()

export default OrderID_API