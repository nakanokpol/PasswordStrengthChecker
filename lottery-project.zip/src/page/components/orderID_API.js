import { createContext } from "react";
import { global_url_token } from '../global_url_token';

const OrderID_API = createContext()

export default OrderID_API