import React from 'react'

function content() {
  return (
    <div>content</div>
  )
}

export default content