import { createContext } from "react";

const ResultForNum = createContext()

export default ResultForNum